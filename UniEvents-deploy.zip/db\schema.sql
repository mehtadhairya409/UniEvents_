-- University Event Management System — Database Schema
-- Run this file in MySQL Workbench or CLI: mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS university_events;
USE university_events;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('student', 'admin') DEFAULT 'student',
  college VARCHAR(150),
  phone VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  category VARCHAR(50),
  date DATE NOT NULL,
  time TIME NOT NULL,
  venue VARCHAR(200),
  capacity INT NOT NULL,
  seats_available INT NOT NULL,
  banner_url VARCHAR(500),
  created_by INT,
  status ENUM('upcoming', 'ongoing', 'completed', 'cancelled') DEFAULT 'upcoming',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS registrations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  event_id INT NOT NULL,
  qr_code_data VARCHAR(500),
  checked_in BOOLEAN DEFAULT false,
  registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_registration (user_id, event_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (event_id) REFERENCES events(id)
);

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  message TEXT NOT NULL,
  type VARCHAR(50),
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Seed: Admin user (password = "password")
INSERT IGNORE INTO users (name, email, password_hash, role, college) VALUES
('Admin User', 'admin@university.edu', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'University Admin');

-- Seed: Events
INSERT IGNORE INTO events (title, description, category, date, time, venue, capacity, seats_available, banner_url, created_by, status) VALUES
('TechFest 2025 - National Hackathon', 'Join 500+ developers for 24 hours of innovation, coding, and prizes worth 1 lakh. Mentors from Google, Microsoft, and startups will guide you.', 'Technical', '2025-06-15', '09:00:00', 'Main Auditorium, Block A', 200, 47, 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800', 1, 'upcoming'),
('Cultural Night - Rang De Basanti', 'Annual cultural extravaganza featuring dance, music, drama, and fashion show. Celebrate the vibrant culture of our campus.', 'Cultural', '2025-06-20', '18:00:00', 'Open Air Theatre', 500, 123, 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800', 1, 'upcoming'),
('AI/ML Workshop with Industry Experts', 'Hands-on workshop covering machine learning fundamentals, neural networks, and real-world applications. Bring your laptop.', 'Workshop', '2025-06-18', '10:00:00', 'Computer Lab 301', 60, 8, 'https://images.unsplash.com/photo-1677442135703-1787eea5ce01?w=800', 1, 'upcoming'),
('Annual Sports Meet 2025', 'Inter-department sports competition covering cricket, football, basketball, and athletics. Register your team now.', 'Sports', '2025-06-25', '07:00:00', 'University Sports Complex', 300, 215, 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800', 1, 'upcoming'),
('Research Paper Presentation', 'Present your research to a panel of professors and industry experts. Best papers will be published in the university journal.', 'Academic', '2025-07-01', '11:00:00', 'Seminar Hall, Block C', 100, 34, 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=800', 1, 'upcoming');
