const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, '..', 'data', 'university_events.db');

// Ensure data directory exists
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ── Create tables ─────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,
    email      TEXT    UNIQUE NOT NULL,
    password   TEXT    NOT NULL,
    role       TEXT    NOT NULL DEFAULT 'student',
    college    TEXT,
    phone      TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS events (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    title            TEXT    NOT NULL,
    description      TEXT,
    category         TEXT    NOT NULL DEFAULT 'General',
    date             TEXT    NOT NULL,
    time             TEXT    NOT NULL,
    venue            TEXT    NOT NULL,
    capacity         INTEGER NOT NULL DEFAULT 100,
    seats_available  INTEGER NOT NULL DEFAULT 100,
    banner_url       TEXT,
    status           TEXT    NOT NULL DEFAULT 'upcoming',
    created_by       INTEGER,
    created_at       DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS registrations (
    id            INTEGER  PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER  NOT NULL,
    event_id      INTEGER  NOT NULL,
    qr_code_data  TEXT     NOT NULL,
    checked_in    INTEGER  NOT NULL DEFAULT 0,
    registered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, event_id),
    FOREIGN KEY(user_id)  REFERENCES users(id),
    FOREIGN KEY(event_id) REFERENCES events(id)
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    message    TEXT    NOT NULL,
    type       TEXT    NOT NULL DEFAULT 'info',
    is_read    INTEGER NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

// ── Seed data if empty ────────────────────────────────────────
const bcrypt = require('bcryptjs');

const adminExists = db.prepare('SELECT id FROM users WHERE email = ?').get('admin@university.edu');
if (!adminExists) {
  const hash = bcrypt.hashSync('password', 10);
  db.prepare(`INSERT INTO users (name, email, password, role) VALUES (?,?,?,?)`).run('Admin User', 'admin@university.edu', hash, 'admin');
  console.log('✅ Admin user seeded: admin@university.edu / password');
}

const eventsCount = db.prepare('SELECT COUNT(*) as c FROM events').get();
if (eventsCount.c === 0) {
  const adminId = db.prepare('SELECT id FROM users WHERE email = ?').get('admin@university.edu').id;
  const insertEvent = db.prepare(`
    INSERT INTO events (title, description, category, date, time, venue, capacity, seats_available, banner_url, status, created_by)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)
  `);
  const today = new Date();
  const d = (offset) => new Date(today.getTime() + offset * 86400000).toISOString().split('T')[0];

  insertEvent.run('TechFest 2025 — National Hackathon', 'A 48-hour hackathon open to all engineering students. Build, innovate, and win exciting prizes across AI, Web3, and sustainability tracks.', 'Technical', d(5),  '09:00', 'Main Auditorium, Block A', 200, 153, 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800', 'upcoming', adminId);
  insertEvent.run('Cultural Night 2025', 'An evening of music, dance, drama, and art celebrating the diverse talent of our university students. Open to all.', 'Cultural', d(8),  '18:30', 'Open Air Theatre', 500, 312, 'https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=800', 'upcoming', adminId);
  insertEvent.run('AI/ML Workshop — Hands-On Deep Learning', 'A practical 6-hour workshop covering neural networks, PyTorch, and deploying ML models. Bring your laptop.', 'Workshop', d(3),  '10:00', 'Computer Lab 3, Block B', 60,  8,   'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800', 'upcoming', adminId);
  insertEvent.run('Inter-College Cricket Tournament', 'Annual cricket championship featuring 16 teams from colleges across the district. Come cheer your team!', 'Sports',   d(12), '08:00', 'University Cricket Ground', 300, 247, 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800', 'upcoming', adminId);
  insertEvent.run('Research Symposium 2025', 'Present and publish your research. Topics include biotech, materials science, sustainability, and computer science.', 'Academic', d(15), '09:30', 'Conference Hall, Admin Block', 150, 89,  'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800', 'upcoming', adminId);

  console.log('✅ 5 sample events seeded');
}

// ── Helper: adapt better-sqlite3 to async-like API ──────────
// Returns a mysql2-compatible object so routes work unchanged
const adapter = {
  query: (sql, params = []) => {
    try {
      const normalized = sql.trim().toUpperCase();
      if (normalized.startsWith('SELECT') || normalized.startsWith('SHOW') || normalized.startsWith('DESCRIBE') || normalized.startsWith('WITH')) {
        const stmt = db.prepare(sql);
        const rows = stmt.all(...params);
        return Promise.resolve([rows]);
      } else if (normalized.startsWith('INSERT')) {
        const stmt = db.prepare(sql);
        const info = stmt.run(...params);
        return Promise.resolve([{ insertId: info.lastInsertRowid, affectedRows: info.changes }]);
      } else {
        const stmt = db.prepare(sql);
        const info = stmt.run(...params);
        return Promise.resolve([{ affectedRows: info.changes }]);
      }
    } catch (err) {
      return Promise.reject(err);
    }
  },
  getConnection: () => {
    // Return a connection-like object that supports transactions
    let committed = false;
    const conn = {
      query: adapter.query,
      beginTransaction: () => { db.prepare('BEGIN').run(); return Promise.resolve(); },
      commit: () => { db.prepare('COMMIT').run(); committed = true; return Promise.resolve(); },
      rollback: () => { if (!committed) { try { db.prepare('ROLLBACK').run(); } catch {} } return Promise.resolve(); },
      release: () => Promise.resolve(),
    };
    return Promise.resolve(conn);
  }
};

module.exports = adapter;
